// =============================================
//  GARDEN HORIZONS 2 — Farmer Entity
//  Движение: абсолютное позиционирование
//  относительно #garden-world (viewport coords).
//  transform: translateX(-50%) для центрирования.
//  Накопление смещений ИСКЛЮЧЕНО.
// =============================================

export class Farmer {
  constructor(element) {
    this.el         = element;
    this.currentPlot = null;
    this.isWorking   = false;
    this.isWalking   = false;
  }

  /**
   * Получить центр грядки в пикселях относительно viewport,
   * затем пересчитать в координаты внутри #garden-world.
   * @param {number} plotIdx
   * @returns {{ leftPx: number, bottomPx: number }}
   */
  _getPlotCenter(plotIdx) {
    const plotEl  = document.querySelector(`.plot[data-plot="${plotIdx}"]`);
    const worldEl = document.getElementById('garden-world');

    if (!plotEl || !worldEl) {
      // Фallback — центр мира
      const wRect = worldEl?.getBoundingClientRect() ?? { left: 0, top: 0, width: window.innerWidth, height: 300 };
      return { leftPx: wRect.left + wRect.width / 2, bottomPx: 90 };
    }

    const plotRect  = plotEl.getBoundingClientRect();
    const worldRect = worldEl.getBoundingClientRect();

    // Центр X в системе координат viewport
    const centerViewportX = plotRect.left + plotRect.width / 2;
    // Конвертируем в координаты внутри garden-world (для left:)
    const leftPx = centerViewportX - worldRect.left;
    // bottom = расстояние от низа garden-world до центра грядки
    const bottomPx = worldRect.bottom - (plotRect.top + plotRect.height * 0.65);

    return { leftPx, bottomPx: Math.max(bottomPx, 60) };
  }

  /**
   * Переместить фермера к грядке.
   * Использует left/bottom (не viewport, а внутри garden-world).
   */
  moveToPlot(plotIdx, _ignored, onArrived) {
    this.currentPlot = plotIdx;
    const { leftPx, bottomPx } = this._getPlotCenter(plotIdx);

    // Позиционируем фермера: left — от левого края garden-world
    this.el.style.left      = `${leftPx}px`;
    this.el.style.bottom    = `${bottomPx}px`;
    this.el.style.transform = 'translateX(-50%)';

    this.setWalking(true);

    setTimeout(() => {
      this.setWalking(false);
      if (onArrived) onArrived();
    }, 650);
  }

  /**
   * Вернуть фермера в центр сетки грядок.
   */
  resetToCenter() {
    const gridEl  = document.getElementById('garden-grid');
    const worldEl = document.getElementById('garden-world');

    if (gridEl && worldEl) {
      const gridRect  = gridEl.getBoundingClientRect();
      const worldRect = worldEl.getBoundingClientRect();

      const leftPx   = (gridRect.left + gridRect.width / 2) - worldRect.left;
      const bottomPx = worldRect.bottom - (gridRect.top + gridRect.height / 2);

      this.el.style.left      = `${leftPx}px`;
      this.el.style.bottom    = `${Math.max(bottomPx, 60)}px`;
      this.el.style.transform = 'translateX(-50%)';
    } else {
      // CSS fallback
      this.el.style.left      = '50%';
      this.el.style.bottom    = '100px';
      this.el.style.transform = 'translateX(-50%)';
    }

    this.currentPlot = null;
    this.setWalking(false);
    this.setWorking(false);
  }

  setWorking(val) {
    this.isWorking = val;
    if (val) {
      this.el.classList.add('working');
      this.el.classList.remove('walking');
    } else {
      this.el.classList.remove('working');
    }
  }

  setWalking(val) {
    this.isWalking = val;
    if (val) {
      this.el.classList.add('walking');
      this.el.classList.remove('working');
    } else {
      this.el.classList.remove('walking');
    }
  }
}
