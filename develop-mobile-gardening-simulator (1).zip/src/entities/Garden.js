// =============================================
//  GARDEN HORIZONS 2 — Garden / Plot Entity
// =============================================

import { SEEDS } from '../logic/Seeds.js';
import { rollMutation, applyMutationEffects, getSellMultiplier } from '../logic/Mutations.js';
import { addToInventory } from '../logic/GameState.js';

export const GROWTH_STAGES = [0, 0.25, 0.6, 1.0]; // fraction of grow time

/**
 * Plant a seed in a plot.
 * @param {object} plot - plot state object
 * @param {string} seedId
 * @param {boolean} isSolarDawn - if true, force solar mutation
 * @returns {object} updated plot
 */
export function plantSeed(plot, seedId, isSolarDawn = false) {
  if (plot.seedId !== null) return plot; // already planted

  // Roll mutation (5% chance, or forced solar)
  const mutation = isSolarDawn
    ? rollMutation(true) // force solar
    : rollMutation(false);

  return {
    ...plot,
    seedId,
    plantedAt: Date.now(),
    mutation,
    stage: 0,
    harvesting: false,
  };
}

/**
 * Update plot growth stage based on elapsed time.
 * @param {object} plot
 * @returns {object} updated plot with stage
 */
export function updatePlotGrowth(plot) {
  if (!plot.seedId || !plot.plantedAt) return plot;

  const seed = SEEDS[plot.seedId];
  if (!seed) return plot;

  const elapsed = (Date.now() - plot.plantedAt) / 1000; // seconds
  const growTime = seed.growTime;
  const fraction = Math.min(1, elapsed / growTime);

  let stage = 0;
  if (fraction >= GROWTH_STAGES[3]) stage = 3;
  else if (fraction >= GROWTH_STAGES[2]) stage = 2;
  else if (fraction >= GROWTH_STAGES[1]) stage = 1;
  else stage = 0;

  return { ...plot, stage, growFraction: fraction };
}

/**
 * Check if a plot is ready to harvest.
 */
export function isPlotReady(plot) {
  if (!plot.seedId || !plot.plantedAt) return false;
  const seed = SEEDS[plot.seedId];
  if (!seed) return false;
  const elapsed = (Date.now() - plot.plantedAt) / 1000;
  return elapsed >= seed.growTime;
}

/**
 * Harvest a plot — returns updated inventory, money, and cleared plot.
 * Has a 500ms delay (caller should handle with setTimeout).
 * @param {object} plot
 * @param {Array} inventory
 * @param {number} money
 * @param {number} premium
 * @param {object|null} activeEvent
 * @returns {{ newPlot, newInventory, newMoney, newPremium, messages }}
 */
export function harvestPlot(plot, inventory, money, premium, activeEvent) {
  const seed = SEEDS[plot.seedId];
  if (!seed) return null;

  // Calculate base yield
  const baseYield = Math.floor(
    Math.random() * (seed.yieldMax - seed.yieldMin + 1)
  ) + seed.yieldMin;

  // Apply mutations
  const { finalYield, premiumYield, transformedSeedId, messages } =
    applyMutationEffects(plot, seed, baseYield, activeEvent);

  let newInventory = [...inventory];
  let newMoney = money;
  let newPremium = premium;

  const isSolar =
    plot.mutation === 'solar' ||
    (activeEvent?.id === 'solarDawn' && plot.mutation !== 'solar');

  if (transformedSeedId) {
    // Void mutation: add transformed seed to inventory as a seed item
    newInventory = addToInventory(newInventory, transformedSeedId, finalYield, 'seed', null, false);
  } else {
    // Add crops to inventory
    newInventory = addToInventory(newInventory, plot.seedId, finalYield, 'crop', plot.mutation, isSolar);
  }

  if (premiumYield > 0) {
    newPremium += premiumYield;
  }

  const newPlot = {
    id: plot.id,
    seedId: null,
    plantedAt: null,
    mutation: null,
    stage: 0,
    harvesting: false,
    growFraction: 0,
  };

  return { newPlot, newInventory, newMoney, newPremium, messages };
}

/**
 * Get the growth progress percentage (0–100) for a plot.
 */
export function getGrowthPercent(plot) {
  if (!plot.seedId || !plot.plantedAt) return 0;
  const seed = SEEDS[plot.seedId];
  if (!seed) return 0;
  const elapsed = (Date.now() - plot.plantedAt) / 1000;
  return Math.min(100, (elapsed / seed.growTime) * 100);
}

/**
 * Get the correct emoji for a plot based on stage.
 */
export function getPlotEmoji(plot) {
  const seed = SEEDS[plot.seedId];
  if (!seed) return '';

  const stageEmojis = ['🌱', '🌿', '🌾', seed.emoji];
  return stageEmojis[Math.min(plot.stage ?? 0, 3)];
}
